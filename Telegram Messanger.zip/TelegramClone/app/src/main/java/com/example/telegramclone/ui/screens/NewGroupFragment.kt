package com.example.telegramclone.ui.screens

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.View
import com.example.telegramclone.R

class NewGroupFragment : Fragment(R.layout.fragment_new_group) {

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

    }
}