package com.example.telegramclone.ui.screens

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.View
import com.example.telegramclone.R
import com.example.telegramclone.ui.base.BaseFragment


class NewChannelFragment : BaseFragment(R.layout.fragment_new_channel) {

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

    }

}